package interfaceWalkthrough;

public class Cow implements Mammal, Animal {
	
	public void speak() {
		System.out.println("Moo!");
	}
	
	public void run() {
		System.out.println("Cows can run at a top speed of 20mph!"); 
	}

	public void eat() {
		
	System.out.println("Cows eat grass.");
		
	}
	

}
