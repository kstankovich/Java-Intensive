package interfaceWalkthrough;

public interface Mammal extends Animal{
	
	void speak();
	void run();
	
}
