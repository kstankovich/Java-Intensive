package interfaceWalkthrough;

public class Dog implements Mammal, Animal {
	
	public void speak() {
		System.out.println("Bark!");
	}
	
	public void run() {
		System.out.println("Dogs can run at a top speed of 45mph!"); 
	}

	public void eat() {
		
	System.out.println("Dogs eat Bones.");
		
	}
	

}
