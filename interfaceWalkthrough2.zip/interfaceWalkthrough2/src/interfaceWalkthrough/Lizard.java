package interfaceWalkthrough;

public class Lizard implements Reptile, Animal {
	
	
	public void crawl() {
		System.out.println("Lizards crawl a bit faster than turtles!"); 
	}

	public void eat() {
		System.out.println("Lizards eat crickets.");
		
	}
	

}
