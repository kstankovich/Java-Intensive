package interfaceWalkthrough;

public interface Reptile extends Animal {
	void crawl();
	

}
