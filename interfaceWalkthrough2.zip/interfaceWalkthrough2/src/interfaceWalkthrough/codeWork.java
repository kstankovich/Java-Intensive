package interfaceWalkthrough;

public class codeWork {
	public static void main(String[] args) {
		
		Dog fido = new Dog();
		fido.speak();
		fido.run();
		fido.eat();
		
		Cat grog = new Cat();
		grog.speak();
		grog.run();
		grog.eat();
		
		Cow fatty = new Cow();
		fatty.speak();
		fatty.run();
		fatty.eat();
		
		Turtle tob = new Turtle();
		tob.crawl();
		tob.eat();
		
		Lizard kerb = new Lizard();
		kerb.crawl();
		kerb.eat();
		
		
	}
}
