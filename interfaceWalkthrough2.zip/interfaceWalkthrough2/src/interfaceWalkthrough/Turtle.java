package interfaceWalkthrough;

public class Turtle implements Reptile, Animal {
	
	
	public void crawl() {
		System.out.println("Turtles crawl very slowly!"); 
	}

	public void eat() {
		System.out.println("Turtles eat lettuce.");
		
	}
	

}
