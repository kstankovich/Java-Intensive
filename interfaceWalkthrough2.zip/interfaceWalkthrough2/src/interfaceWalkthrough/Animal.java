package interfaceWalkthrough;

public interface Animal {
	
	void eat();
	
	

}
