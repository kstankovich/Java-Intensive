package interfaceWalkthrough;

public class Cat implements Mammal, Animal {
	
	public void speak() {
		System.out.println("Meow!");
	}
	
	public void run() {
		System.out.println("Cats can run at a top speed of 30mph!"); 
	}

	public void eat() {
		
	System.out.println("Cats eat mice.");
		
	}
	

}
