package com.KyleStankovich.HandsOn1;

public class HandsOn {

	public static void main(String[] args) {
		boolean isSunny = true;
		boolean atBeach = true;
		
		if(isSunny) {
			System.out.println("Wear sunglasses!");
			
			if(atBeach) {
				System.out.println("Wear Sunblock!");
			}
		
			else {
				System.out.println("Don't need sun block.");
			}
		}
		else {
			System.out.println("Don't need to wear sunglasses.");
			
			if (atBeach) {
				System.out.println("Come back tomorrow.");
			}
			else {
				System.out.println("Don't go to the beach.");
			}
		}

	}
	

}
