package com.viewControllerStory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViewControllerStoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViewControllerStoryApplication.class, args);
	}

}
