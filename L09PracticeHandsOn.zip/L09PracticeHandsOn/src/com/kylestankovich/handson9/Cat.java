package com.kylestankovich.handson9;

public class Cat extends Animal{

}
