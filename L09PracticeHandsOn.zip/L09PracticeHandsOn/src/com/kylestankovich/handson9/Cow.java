package com.kylestankovich.handson9;

public class Cow extends Animal{

}
